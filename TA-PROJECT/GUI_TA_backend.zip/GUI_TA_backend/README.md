# Backend Tab Input & Validasi GUI TA

Backend ini digunakan untuk:

1. Membaca `summary_optimized_results.csv`.
2. Menjadikan CSV sebagai database citra.
3. Memvalidasi citra berdasarkan kolom `File Name`.
4. Mengambil variabel keputusan baseline `X0` dan optimized `X*(P_i)`.

## Struktur

```text
backend/
├── __init__.py
├── config.py
└── input_validation.py
```

## Parameter baseline

```text
X0 = [3.70, 0.02, 500, 256]
```

Dengan pemetaan:

```text
r_min = 3.70
eps   = 0.02
T0    = 500
Q     = 256
```

## Kolom CSV yang digunakan

```text
File Name
Category
Best_Fitness
Opt_r_min
Opt_eps
Opt_T0
Opt_Q
```

## Contoh pemakaian di GUI

```python
from backend import InputValidationBackend

self.validator = InputValidationBackend()

csv_result = self.validator.load_csv(csv_path)
if csv_result["ok"]:
    print("CSV valid")

image_result = self.validator.validate_image(image_path)
if image_result["ok"]:
    x0 = image_result["x0"]
    xopt = image_result["xopt"]
```

## Integrasi ke tombol GUI

Pada class GUI, tambahkan di `__init__`:

```python
from backend import InputValidationBackend
self.validator = InputValidationBackend()
```

Lalu pada fungsi input CSV:

```python
result = self.validator.load_csv(file_path)
```

Pada fungsi input citra:

```python
result = self.validator.validate_image(file_path)
```

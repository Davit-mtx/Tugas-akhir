"""Backend package untuk GUI TA enkripsi citra."""

from .input_validation import InputValidationBackend

__all__ = ["InputValidationBackend"]

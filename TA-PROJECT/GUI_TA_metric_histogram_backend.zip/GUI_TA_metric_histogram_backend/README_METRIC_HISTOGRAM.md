# Backend Evaluasi Metrik dan Histogram GUI TA

File yang ditambahkan:

```text
backend/
├── evaluation_metrics.py
├── histogram_generator.py
└── __init__.py  # versi update

main_gui_integrated.py  # contoh main_gui.py yang sudah diintegrasikan
```

## Cara pemasangan manual

1. Copy `backend/evaluation_metrics.py` ke folder `GUI/backend/`.
2. Copy `backend/histogram_generator.py` ke folder `GUI/backend/`.
3. Update `GUI/backend/__init__.py` sesuai file pada ZIP ini.
4. Terapkan perubahan pada `main_gui.py`, atau gunakan `main_gui_integrated.py` sebagai referensi.

## Import GUI

```python
from backend import (
    InputValidationBackend,
    ProcessPipelineBackend,
    EvaluationMetricsBackend,
    HistogramGeneratorBackend,
)
```

## Inisialisasi dalam `__init__` class GUI

```python
self.metric_evaluator = EvaluationMetricsBackend()
self.histogram_generator = HistogramGeneratorBackend(output_root="output/gui_histogram")
self.metrics_result = None
self.histogram_result = None
```

## Alur pemakaian GUI

1. Input CSV optimized.
2. Input citra valid.
3. Jalankan `Baseline & Optimized`.
4. Masuk tab `Evaluasi Metrik`, klik `Hitung Evaluasi Metrik`.
5. Masuk tab `Histogram`, klik `Buat Histogram`.

## Dependensi

```bash
pip install opencv-python matplotlib numpy
```

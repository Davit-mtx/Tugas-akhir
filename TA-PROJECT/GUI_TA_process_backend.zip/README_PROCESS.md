# Backend Tab Proses Citra GUI TA

Backend ini menjalankan dua proses sekaligus:

1. Baseline menggunakan `X0`.
2. Optimized menggunakan `X*(P_i)` dari payload validasi.

## File yang ditambahkan

```text
backend/
├── process_pipeline.py
└── __init__.py  # versi update agar ProcessPipelineBackend bisa di-import
```

## Sumber pipeline

Backend ini membutuhkan fungsi berikut dari `pipeline.py`:

```python
encrypt_baseline
decrypt_baseline
BaselineConfig
```

Letakkan `pipeline.py` pada salah satu struktur berikut:

```text
GUI_TA/pipeline.py
```

atau:

```text
GUI_TA/src/crypto/pipeline.py
```

## Import di GUI

```python
from backend import InputValidationBackend, ProcessPipelineBackend
```

Di `__init__` class GUI:

```python
self.validator = InputValidationBackend()
self.processor = ProcessPipelineBackend(output_root="output/gui_process")
self.process_result = None
```

## Pemakaian

```python
payload = self.validator.get_current_payload()
result = self.processor.run_baseline_and_optimized(payload)
```

Output utama:

```python
result["input"]["original_path"]
result["baseline"]["cipher_path"]
result["baseline"]["decrypted_path"]
result["optimized"]["cipher_path"]
result["optimized"]["decrypted_path"]
```

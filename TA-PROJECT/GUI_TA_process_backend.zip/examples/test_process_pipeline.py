"""
Contoh pengujian backend Tab Proses Citra tanpa GUI.

Cara pakai:
1. Pastikan backend/, pipeline.py, summary_optimized_results.csv, dan citra valid berada pada project yang sama.
2. Ubah CSV_PATH dan IMAGE_PATH sesuai lokasi file di laptop.
3. Jalankan:
   python examples/test_process_pipeline.py
"""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import InputValidationBackend, ProcessPipelineBackend

CSV_PATH = "summary_optimized_results.csv"
IMAGE_PATH = "I04_04_01.png"

if __name__ == "__main__":
    validator = InputValidationBackend()
    processor = ProcessPipelineBackend(output_root="output/gui_process")

    csv_result = validator.load_csv(CSV_PATH)
    print("CSV:", csv_result)

    image_result = validator.validate_image(IMAGE_PATH)
    print("VALIDATION:", image_result)

    process_result = processor.run_baseline_and_optimized(image_result)
    print("PROCESS:", process_result)
